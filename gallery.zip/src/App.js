import React from 'react';
import Gallery from './gallery.js';

const App = () => {
  return (
    <>
      <Gallery />
    </>
  );
}
export default App;
