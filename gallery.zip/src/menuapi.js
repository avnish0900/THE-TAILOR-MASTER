const Menu = [
  {
    id: 1,
    image: "./img/4883888b-a1c2-4a1e-877b-a7c5f5549652.jfif",
    name:"Formal-Suit",
    category: "Formal-Suit",
    bigCategory:"Suit",
    price: "20₹",
    description:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Blanditiis, at consectetur totam voluptatibus quibusdam iusto. Accusamus quas, soluta ipsam autem eius necessitatibus fugiat in . ",
  },
  {
    id: 2,
    image: "./img/59e88c73-478a-4ba1-8cac-2fec6d44e5d0.jfif",
    name:"Casual-Suit",
    category: "Casual-Suit",
    bigCategory:"Suit",
    price: "20₹",
    description:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Blanditiis, at consectetur totam voluptatibus quibusdam iusto. Accusamus quas, soluta ipsam autem eius necessitatibus fugiat in . ",
  },
  {
    id: 3,
    image: "./img/8f96241b-2243-4a80-8886-ec0046925d55.jfif",
    name:"Casual-Suit",
    category: "Casual-Suit",
    bigCategory:"Suit",
    price: "20₹",
    description:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Blanditiis, at consectetur totam voluptatibus quibusdam iusto. Accusamus quas, soluta ipsam autem eius necessitatibus fugiat in . ",
  },
  {
    id: 4,
    image:"https://i.pinimg.com/564x/91/bb/d5/91bbd5ef4c3aae64cd86e8c308456f79.jpg",
    name: "Party Wear",
    category: "Party Wear",
    bigCategory:"Suit",
    price: "12₹",
    description:
      "I love Maggi realy oo yues  Lorem ipsum dolor sit amet consectetur adipisicing elit. Blanditiis, at consectetur totam voluptatibus quibusdam iusto. Accusamus quas, soluta ipsam autem eius necessitatibus fugiat in . ",
  },

  {
    id: 5,
    image: "https://i.pinimg.com/564x/93/6e/c0/936ec0a55b3dae1ddfc36f57bbc21b99.jpg",
    name:"Casual-Suit",
    category: "Casual-Suit",
    bigCategory:"Suit",
    price: "20₹",
    description:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Blanditiis, at consectetur totam voluptatibus quibusdam iusto. Accusamus quas, soluta ipsam autem eius necessitatibus fugiat in . ",
  },
  {
    id: 6,
    image: "https://i.pinimg.com/564x/3f/b7/38/3fb738b74036c19a032cb9f99bf37117.jpg",
    name:"Business-Suit",
    category: "Business-Suit",
    bigCategory:"Suit",
    price: "20₹",
    description:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Blanditiis, at consectetur totam voluptatibus quibusdam iusto. Accusamus quas, soluta ipsam autem eius necessitatibus fugiat in . ",
  },
  {
    id: 7,
    image: "https://i.pinimg.com/564x/d9/63/1d/d9631d1f4c0ff618df1bdbb709990d13.jpg",
    name:"Formal-Pant",
    category: "Formal-Pant",
    bigCategory:"Pant",
    price: "20₹",
    description:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Blanditiis, at consectetur totam voluptatibus quibusdam iusto. Accusamus quas, soluta ipsam autem eius necessitatibus fugiat in . ",
  },
  {
    id: 8,
    image: "https://i.pinimg.com/564x/d5/5c/28/d55c28a3ab82825d8e4896ba790b946f.jpg",
    name:"Formal-Pant",
    category: "Formal-Pant",
    bigCategory:"Pant",
    price: "20₹",
    description:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Blanditiis, at consectetur totam voluptatibus quibusdam iusto. Accusamus quas, soluta ipsam autem eius necessitatibus fugiat in . ",
  },
  {
    id: 9,
    image: "https://i.pinimg.com/564x/78/d5/42/78d542e99edfde90fc893372a7fef387.jpg",
    name:"Formal-Pant",
    category: "Formal-Pant",
    bigCategory:"Pant",
    price: "20₹",
    description:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Blanditiis, at consectetur totam voluptatibus quibusdam iusto. Accusamus quas, soluta ipsam autem eius necessitatibus fugiat in . ",
  },
  {
    id: 10,
    image: "https://i.pinimg.com/564x/17/ad/0b/17ad0bfd6a8934bc6390bad389426241.jpg",
    name:"Casual-Pant",
    category: "Casual-Pant",
    bigCategory:"Pant",
    price: "20₹",
    description:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Blanditiis, at consectetur totam voluptatibus quibusdam iusto. Accusamus quas, soluta ipsam autem eius necessitatibus fugiat in . ",
  },
  {
    id: 11,
    image: "https://i.pinimg.com/564x/c8/4c/98/c84c98d535f767648a06acae598f9e0a.jpg",
    name:"Formal-Pant",
    category: "Formal-Pant",
    bigCategory:"Pant",
    price: "20₹",
    description:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Blanditiis, at consectetur totam voluptatibus quibusdam iusto. Accusamus quas, soluta ipsam autem eius necessitatibus fugiat in . ",
  },
  {
    id: 12,
    image: "https://i.pinimg.com/564x/79/e3/c4/79e3c4e756cb233f6074236bfac566cb.jpg",
    name:"Casual-Suit",
    category: "Casual-Suit",
    bigCategory:"Shirt",
    price: "20₹",
    description:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Blanditiis, at consectetur totam voluptatibus quibusdam iusto. Accusamus quas, soluta ipsam autem eius necessitatibus fugiat in . ",
  },
  {
    id: 13,
    image: "https://i.pinimg.com/564x/bd/0c/d6/bd0cd663bd8045042310b946b5f66c6a.jpg",
    name:"Casual-Suit",
    category: "Casual-Suit",
    bigCategory:"Shirt",
    price: "20₹",
    description:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Blanditiis, at consectetur totam voluptatibus quibusdam iusto. Accusamus quas, soluta ipsam autem eius necessitatibus fugiat in . ",
  },
  {
    id: 14,
    image: "https://i.pinimg.com/564x/1f/e5/e8/1fe5e8d7006e0a99ea6d82d78bbb3d91.jpg",
    name:"Casual-Suit",
    category: "Casual-Suit",
    bigCategory:"Shirt",
    price: "20₹",
    description:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Blanditiis, at consectetur totam voluptatibus quibusdam iusto. Accusamus quas, soluta ipsam autem eius necessitatibus fugiat in . ",
  },
  {
    id: 15,
    image: "https://i.pinimg.com/564x/58/e8/08/58e808ff15be7d42c4505b6abf5c7be8.jpg",
    name:"Casual-Suit",
    category: "Casual-Suit",
    bigCategory:"Shirt",
    price: "20₹",
    description:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Blanditiis, at consectetur totam voluptatibus quibusdam iusto. Accusamus quas, soluta ipsam autem eius necessitatibus fugiat in . ",
  },
  {
    id: 16,
    image: "https://i.pinimg.com/564x/b2/8c/1f/b28c1f188d8788b4aaf39f82178bfcf7.jpg",
    name:"Casual-Suit",
    category: "Casual-Suit",
    bigCategory:"Shirt",
    price: "20₹",
    description:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Blanditiis, at consectetur totam voluptatibus quibusdam iusto. Accusamus quas, soluta ipsam autem eius necessitatibus fugiat in . ",
  },
  {
    id: 17,
    image: "https://i.pinimg.com/564x/61/14/e6/6114e6c7f2093128f4fcb8efd8c4c29d.jpg",
    name:"Casual-Suit",
    category: "Casual-Suit",
    bigCategory:"Shirt",
    price: "20₹",
    description:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Blanditiis, at consectetur totam voluptatibus quibusdam iusto. Accusamus quas, soluta ipsam autem eius necessitatibus fugiat in . ",
  },
  {
    id: 18,
    image: "https://i.pinimg.com/564x/3f/c5/28/3fc528b7f06cf464d24d29ada07514a3.jpg",
    name:"Casual-Suit",
    category: "Casual-Suit",
    bigCategory:"Shirt",
    price: "20₹",
    description:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Blanditiis, at consectetur totam voluptatibus quibusdam iusto. Accusamus quas, soluta ipsam autem eius necessitatibus fugiat in . ",
  },
  {
    id: 19,
    image: "https://i.pinimg.com/564x/03/a4/fd/03a4fdae3f0a29f82eb9598a88595081.jpg",
    name:"Casual-Suit",
    category: "Casual-Suit",
    bigCategory:"Shirt",
    price: "20₹",
    description:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Blanditiis, at consectetur totam voluptatibus quibusdam iusto. Accusamus quas, soluta ipsam autem eius necessitatibus fugiat in . ",
  },
  {
    id: 20,
    image: "https://i.pinimg.com/564x/f2/aa/b0/f2aab0e3c929fa036e1ec5236d016fd2.jpg",
    name:"Casual-Suit",
    category: "Casual-Suit",
    bigCategory:"Shirt",
    price: "20₹",
    description:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Blanditiis, at consectetur totam voluptatibus quibusdam iusto. Accusamus quas, soluta ipsam autem eius necessitatibus fugiat in . ",
  },
  {
    id: 21,
    image: "https://i.pinimg.com/564x/9c/25/a7/9c25a7111dd27b12cc343bcad6d2d006.jpg",
    name:"Casual-Wear",
    category: "Casual-Wear",
    bigCategory:"Sherwani",
    price: "20₹",
    description:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Blanditiis, at consectetur totam voluptatibus quibusdam iusto. Accusamus quas, soluta ipsam autem eius necessitatibus fugiat in . ",
  },
  {
    id: 22,
    image: "https://i.pinimg.com/564x/68/f2/7f/68f27f8006fa356374f1e0f81aa0b0c3.jpg",
    name:"Party-Wear",
    category: "Party-Wear",
    bigCategory:"Sherwani",
    price: "20₹",
    description:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Blanditiis, at consectetur totam voluptatibus quibusdam iusto. Accusamus quas, soluta ipsam autem eius necessitatibus fugiat in . ",
  },
  {
    id: 23,
    image: "https://i.pinimg.com/564x/bc/74/ba/bc74bae856366417ca0ea39e848ffa1a.jpg",
    name:"Casual-Wear",
    category: "Casual-Wear",
    bigCategory:"Sherwani",
    price: "20₹",
    description:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Blanditiis, at consectetur totam voluptatibus quibusdam iusto. Accusamus quas, soluta ipsam autem eius necessitatibus fugiat in . ",
  },
  {
    id: 24,
    image: "https://i.pinimg.com/564x/85/1d/32/851d32ab2fdf082e96f505fb52ab6603.jpg",
    name:"Weeding-Wear",
    category: "Weeding-Wear",
    bigCategory:"Sherwani",
    price: "20₹",
    description:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Blanditiis, at consectetur totam voluptatibus quibusdam iusto. Accusamus quas, soluta ipsam autem eius necessitatibus fugiat in . ",
  },
  {
    id: 25,
    image: "https://i.pinimg.com/564x/3f/0a/85/3f0a85b477eef7b0848f9f49d3818574.jpg",
   name:"Weeding-Wear",
    category: "Weeding-Wear",
    bigCategory:"Sherwani",
    price: "20₹",
    description:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Blanditiis, at consectetur totam voluptatibus quibusdam iusto. Accusamus quas, soluta ipsam autem eius necessitatibus fugiat in . ",
  },
  {
    id: 26,
    image: "https://i.pinimg.com/564x/34/f5/46/34f546e0f420b1353523959eb5ae09d8.jpg",
    name:"Weeding-Wear",
    category: "Weeding-Wear",
    bigCategory:"Sherwani",
    price: "20₹",
    description:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Blanditiis, at consectetur totam voluptatibus quibusdam iusto. Accusamus quas, soluta ipsam autem eius necessitatibus fugiat in . ",
  },
  {
    id: 27,
    image: "https://i.pinimg.com/564x/99/de/51/99de519dd5174f9b6ffb7afad1cca069.jpg",
   name:"Weeding-Wear",
    category: "Weeding-Wear",
    bigCategory:"Sherwani",
    price: "20₹",
    description:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Blanditiis, at consectetur totam voluptatibus quibusdam iusto. Accusamus quas, soluta ipsam autem eius necessitatibus fugiat in . ",
  },
];

export default Menu;